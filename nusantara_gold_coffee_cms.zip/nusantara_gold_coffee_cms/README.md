# Nusantara Gold Coffee — Bilingual Website + News CMS

## Included
- Existing premium brown-and-gold bilingual public website (English default / Indonesian selector).
- Public News & Insights section populated from published CMS articles.
- Article detail page at `/article.html?slug=...`.
- Admin dashboard at `/admin.html`.
- Admin login, image uploads, bilingual article fields, draft/publish/unpublish/delete.
- SQLite database and local image uploads. Attach a persistent volume at `/data` in production. The SQLite database and uploaded article images are both stored inside this volume.

## Run locally
Requirements: Node.js 20+

```bash
npm install
cp .env.example .env
```

Edit `.env` and set strong unique values for `ADMIN_PASSWORD` and `SESSION_SECRET`, then:

```bash
npm start
```

Open:
- Public website: http://localhost:3000
- Admin dashboard: http://localhost:3000/admin.html

Default username is `admin`; set your own password in `.env`. Never publish with the example password.

## Deploy to Railway
1. Push this folder to a private GitHub repository.
2. In Railway, create a project and deploy the repository.
3. Add a persistent Volume mounted at `/data`.
4. Set environment variables: `ADMIN_USER`, `ADMIN_PASSWORD`, `SESSION_SECRET`, `DATA_DIR=/data`, `PORT=3000`.
5. Generate a public domain for the service.
6. Open `/admin.html` on the deployed domain and sign in.

## Important
- This archive is deploy-ready source code, not a live deployment. No public URL exists until it is deployed to an account you control.
- Configure strong credentials before exposing the admin panel publicly.
- Back up the `/data` volume; it contains both the database and uploaded article images.
- The enquiry form from the original marketing site remains a visual frontend form; connecting it to email/CRM is a separate integration.
