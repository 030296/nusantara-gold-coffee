const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const UPLOAD_DIR = path.join(DATA_DIR, "uploads");
fs.mkdirSync(DATA_DIR, {recursive:true});
fs.mkdirSync(UPLOAD_DIR, {recursive:true});

const db = new Database(path.join(DATA_DIR, "coffee-cms.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS articles (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 slug TEXT NOT NULL UNIQUE,
 title_en TEXT NOT NULL,
 title_id TEXT NOT NULL,
 excerpt_en TEXT DEFAULT '',
 excerpt_id TEXT DEFAULT '',
 body_en TEXT NOT NULL,
 body_id TEXT NOT NULL,
 category TEXT DEFAULT 'Company News',
 image_url TEXT DEFAULT '',
 status TEXT NOT NULL DEFAULT 'draft',
 created_at TEXT NOT NULL,
 published_at TEXT
);
`);

app.use(express.json({limit:"2mb"}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname,"public")));
app.use("/uploads", express.static(UPLOAD_DIR));

const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;

function safeEqual(a,b){
 const aa=Buffer.from(String(a||"")); const bb=Buffer.from(String(b||""));
 return aa.length===bb.length && crypto.timingSafeEqual(aa,bb);
}
function sign(payload){
 const data=Buffer.from(JSON.stringify(payload)).toString("base64url");
 const sig=crypto.createHmac("sha256",SESSION_SECRET).update(data).digest("base64url");
 return data+"."+sig;
}
function verify(token){
 try{
  const [data,sig]=String(token||"").split(".");
  const expected=crypto.createHmac("sha256",SESSION_SECRET).update(data).digest("base64url");
  if(!safeEqual(sig,expected)) return null;
  const payload=JSON.parse(Buffer.from(data,"base64url").toString());
  if(payload.exp<Date.now()) return null;
  return payload;
 }catch{return null;}
}
function requireAdmin(req,res,next){
 const token=(req.headers.authorization||"").replace(/^Bearer\s+/i,"") || req.cookies?.coffee_session;
 const session=verify(token);
 if(!session || session.user!==ADMIN_USER) return res.status(401).json({error:"Unauthorised"});
 next();
}
const storage=multer.diskStorage({
 destination:(req,file,cb)=>cb(null,UPLOAD_DIR),
 filename:(req,file,cb)=>{
  const ext=path.extname(file.originalname).toLowerCase();
  cb(null,Date.now()+"-"+crypto.randomBytes(6).toString("hex")+ext);
 }
});
const upload=multer({
 storage,
 limits:{fileSize:5*1024*1024},
 fileFilter:(req,file,cb)=>{
  const ok=/^image\/(jpeg|png|webp|gif)$/.test(file.mimetype);
  cb(ok?null:new Error("Only JPG, PNG, WEBP, and GIF images are allowed"),ok);
 }
});

app.post("/api/admin/login",(req,res)=>{
 if(!ADMIN_PASSWORD || !SESSION_SECRET) return res.status(503).json({error:"Admin credentials are not configured. Set ADMIN_PASSWORD and SESSION_SECRET."});
 if(!safeEqual(req.body.username,ADMIN_USER) || !safeEqual(req.body.password,ADMIN_PASSWORD))
  return res.status(401).json({error:"Incorrect username or password"});
 const token=sign({user:ADMIN_USER,exp:Date.now()+8*60*60*1000});
 res.json({token,expiresIn:28800});
});
app.get("/api/news",(req,res)=>{
 const items=db.prepare("SELECT slug,title_en,title_id,excerpt_en,excerpt_id,category,image_url,created_at,published_at FROM articles WHERE status='published' ORDER BY COALESCE(published_at,created_at) DESC").all();
 res.json({items});
});
app.get("/api/news/:slug",(req,res)=>{
 const item=db.prepare("SELECT * FROM articles WHERE slug=? AND status='published'").get(req.params.slug);
 if(!item) return res.status(404).json({error:"Article not found"});
 res.json({item});
});
app.get("/api/admin/articles",requireAdmin,(req,res)=>{
 res.json({items:db.prepare("SELECT * FROM articles ORDER BY created_at DESC").all()});
});
app.post("/api/admin/upload",requireAdmin,upload.single("image"),(req,res)=>{
 if(!req.file) return res.status(400).json({error:"Choose an image first"});
 res.json({url:"/uploads/"+req.file.filename});
});
app.post("/api/admin/articles",requireAdmin,(req,res)=>{
 const b=req.body||{};
 const required=["title_en","title_id","body_en","body_id"];
 for(const key of required) if(!String(b[key]||"").trim()) return res.status(400).json({error:"Please complete both English and Indonesian titles and article content."});
 const slug=(b.slug||b.title_en).toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,90);
 const now=new Date().toISOString();
 const status=b.status==="published"?"published":"draft";
 try{
  const info=db.prepare(`INSERT INTO articles(slug,title_en,title_id,excerpt_en,excerpt_id,body_en,body_id,category,image_url,status,created_at,published_at)
  VALUES(@slug,@title_en,@title_id,@excerpt_en,@excerpt_id,@body_en,@body_id,@category,@image_url,@status,@created_at,@published_at)`).run({
   slug,title_en:b.title_en.trim(),title_id:b.title_id.trim(),excerpt_en:b.excerpt_en||"",excerpt_id:b.excerpt_id||"",
   body_en:b.body_en,body_id:b.body_id,category:b.category||"Company News",image_url:b.image_url||"",status,created_at:now,published_at:status==="published"?now:null
  });
  res.status(201).json({id:info.lastInsertRowid,slug});
 }catch(e){res.status(409).json({error:"Could not save article. Check whether its URL slug is already used."});}
});
app.patch("/api/admin/articles/:id/status",requireAdmin,(req,res)=>{
 const status=req.body.status==="published"?"published":"draft";
 const result=db.prepare("UPDATE articles SET status=?,published_at=CASE WHEN ?='published' THEN COALESCE(published_at,?) ELSE NULL END WHERE id=?")
  .run(status,status,new Date().toISOString(),req.params.id);
 if(!result.changes) return res.status(404).json({error:"Article not found"});
 res.json({ok:true});
});
app.delete("/api/admin/articles/:id",requireAdmin,(req,res)=>{
 const item=db.prepare("SELECT image_url FROM articles WHERE id=?").get(req.params.id);
 if(!item) return res.status(404).json({error:"Article not found"});
 db.prepare("DELETE FROM articles WHERE id=?").run(req.params.id);
 if(item.image_url && item.image_url.startsWith("/uploads/")){
  const file=path.join(UPLOAD_DIR,path.basename(item.image_url));
  if(fs.existsSync(file)) fs.unlinkSync(file);
 }
 res.json({ok:true});
});
app.get("/api/health",(req,res)=>res.json({ok:true}));

app.use((err,req,res,next)=>{
 console.error(err);
 res.status(400).json({error:err.message||"Request failed"});
});
app.listen(PORT,"0.0.0.0",()=>console.log("Nusantara Gold Coffee CMS listening on "+PORT));
